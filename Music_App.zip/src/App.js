import './App.css';
import { Header } from './Header/header';
import { Playing } from './MusicPlaying/playing';
import { Playlist } from './Playlist/playlist';
import { Result } from './SearchResult/result';

function App() {
  return (
    <div>
      <div className='row'>
        <div className='col-lg-7 col-xs-12'>
            <Header/>
        </div>
        <div className='col-lg-5 col-xs-12'>
          <Playing/>
        </div>
      </div> &nbsp;
      <div className='row'>
      <div className='col-lg-7 col-xs-12'>
            <Result/>
        </div>
        <div className='col-lg-5 col-xs-12'>
          <Playlist/>
        </div>
      </div>
    </div>
  );
}

export default App;
