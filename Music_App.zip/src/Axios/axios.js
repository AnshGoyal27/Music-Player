import axios from "axios";
import { ActionCreator } from "../Redux/action";
import {store} from "../Redux/store";

export function GetMusic(SearchValue){
    let arr=SearchValue.split(" ")
    let str="";
    arr.forEach((ele,index)=>{
        if(index===(arr.length)-1){
            str+=ele;
        }
        else{
            str+=(ele+"+");
        }
    })
    const URL=process.env.REACT_APP_URL+str
    const promise=axios.get(URL);
    promise.then(ele=>{
        let arr=[]
        if(ele.data.resultCount===0){
            arr=[{
                Track_Name:'-',
                Artist_Name:'-',
                Release_Date:'-',
                SongURL:'-',
                Artist_Pic:'-'
            }]
        }
        else{
            ele.data.results.forEach(elem=>{
                arr.push({
                    Track_Name:elem.trackName,
                    Artist_Name:elem.artistName,
                    Release_Date:elem.releaseDate,
                    SongURL:elem.previewUrl,
                    Artist_Pic:elem.artworkUrl100
                })
                console.log(elem);
                
            });
        }
        const action=ActionCreator('data',arr);
        store.dispatch(action)
    })
    .catch(err=>console.log(err));
    // const promise=axios.get(URL);
    // promise
    // .then(result=>console.log(result))
    // .catch(err=>console.log(err));
}