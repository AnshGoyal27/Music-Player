import { useSelector } from "react-redux"
import { ActionCreator } from "../Redux/action";
import { store } from "../Redux/store";

export const Playlist=()=>{

    let data=useSelector(state=>state)
    let itemdatas=data.playqueue;
    const TableC=process.env.REACT_APP_TABLEHEAD2.split(",");
    console.log(itemdatas);
    

    function playsong(song,artistp,artist){
        if(artist==='-'){
            window.alert('Cant Play');
        }
        else{
            const action=ActionCreator('play',{
                ArtistP:artistp,
                Artist:artist,
                Song:song
            })
            store.dispatch(action);
        }
    }
 
    return(
        <div>
            <div>
                <h1 className="display-3" align="center">PLAY QUEUE</h1>
            </div>
            <div>
            <table className="table table-bordered table-hover table-light">
                <thead className="table-dark">
                    <tr>
                        {TableC.map((ele,index)=><th key={index} scope="col">{ele}</th>)}
                    </tr>
                </thead>
                <tbody>
                    {itemdatas.map((ele,index)=>{
                        return(
                            <tr key={index} onDoubleClick={()=>playsong(ele.SongUrl,ele.ArtistP,ele.Artist)}>
                                <th scope="row" >{index+1}</th>
                                <th>{ele.SongName}</th>
                                <th>{ele.Artist}</th>
                            </tr>
                        )
                    })}
                </tbody>
            </table>
            </div>
        </div>
    )
}