import { Button, TextField } from "@mui/material"
import { GetMusic } from "../Axios/axios"

export const Header=()=>{

    function Search(){
        GetMusic(document.getElementById('SearchBox').value);
    }

    return(
        <div align="center">
            <h1 className="display-1">Music Store</h1>
            <TextField id='SearchBox' label="Search Here" variant="standard" /> 
            <br/>
            <br/>
            <Button onClick={Search} variant="contained">Submit</Button>
        </div>
    )
}