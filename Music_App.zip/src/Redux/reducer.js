export const reducerfn=(state={
    resultdata:[],
    playingNow:{
        ArtistP:'',
        Artist:'',
        Song:'',
    },
    playqueue:[]
},action)=>{
    if(action.type==='data'){
        let arr=[];
        action.payload.forEach(ele=>arr.push(ele));
        console.log(arr);
        return {...state,resultdata:arr};
    }
    else if(action.type==='play'){
        return{...state,playingNow:action.payload}
    }
    else if(action.type==='addq'){
        let arr=state.playqueue;
        arr.push(action.payload)
        return{...state,playqueue:arr}
    }
    return state;
}