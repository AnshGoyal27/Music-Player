import ReactAudioPlayer from "react-audio-player";
import { useSelector } from "react-redux"


export const Playing=()=>{

    const playingNows=useSelector(state=>state.playingNow);
    

    return(
        <div align="center">
            <h1 className="display-3">PLAYING</h1>
            <img src={playingNows.ArtistP} className="img-fluid" alt={playingNows.Artist}/>
            <br/>
            <br/>
            <ReactAudioPlayer src={playingNows.Song} autoPlay controls/>
        </div>
    )
} 