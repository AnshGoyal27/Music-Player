export const Playlist=()=>{
    return(
        <div>
            <h1 className="display-3" align="center">PLAYLIST</h1>
        </div>
    )
}