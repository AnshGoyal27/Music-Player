export const reducerfn=(state={
    resultdata:[],
    playingNow:{
        ArtistP:'',
        Artist:'',
        Song:''
    }
},action)=>{
    if(action.type==='data'){
        let arr=[];
        action.payload.forEach(ele=>arr.push(ele));
        console.log(arr);
        return {...state,resultdata:arr};
    }
    else if(action.type==='play'){
        return{...state,playingNow:action.payload}
    }
    return state;
}